package com.cg.ibs.loanmgmt.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.ibs.loanmgmt.IBSexception.ExceptionMessages;
import com.cg.ibs.loanmgmt.IBSexception.IBSException;
import com.cg.ibs.loanmgmt.bean.BankAdmins;
import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.service.BankService;
import com.cg.ibs.loanmgmt.service.BankServiceImpl;
import com.cg.ibs.loanmgmt.service.CustomerService;
import com.cg.ibs.loanmgmt.service.CustomerServiceImpl;

public class User implements ExceptionMessages {
	private static CustomerService customerService = new CustomerServiceImpl();
	private static BankService bankService = new BankServiceImpl();
	private static Logger LOGGER = Logger.getLogger(User.class);
	private static Scanner read = new Scanner(System.in);

	public void userLogin() throws IBSException {
		UserOptions choice = null;
		CustomerBean client = null;

		while (choice != UserOptions.EXIT) {
			System.out.println("Login as an existing customer or admin? ");
			System.out.println("------------------------");
			for (UserOptions menu : UserOptions.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			String userLoginInput = read.next();
			Pattern pattern = Pattern.compile("[0-9]{1}");
			Matcher matcher = pattern.matcher(userLoginInput);
			if (matcher.matches()) {
				int ordinal = Integer.parseInt(userLoginInput);
				if (ordinal >= 1 && ordinal < (UserOptions.values().length) + 1) {
					choice = UserOptions.values()[ordinal - 1];
					switch (choice) {
					case VISITOR:
						selectLoanType(client);
						break;
					case EXISTING_CUSTOMER:
						init(customerLogin());
						break;
					case BANK_ADMIN:
						adminInit(bankAdminLogin());
						break;
					case EXIT:
						System.out.println("\nThank You For Visiting. \nHave a nice day!");
						break;
					}
				} else {
					choice = null;
					try {
						if (choice == null) {
							throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
						}
					} catch (IBSException exp) {
//						LOGGER.info("User is giving wrong input");
						System.out.println(exp.getMessage());

					}

				}
			} else {
				try {
					throw new IBSException(ExceptionMessages.MESSAGEFORINPUTMISMATCH);
				} catch (IBSException exp) {
					System.out.println(exp.getMessage());
				}
			}
		}
	}

	private LoanMaster selectLoanType(CustomerBean customer) throws IBSException {
		LOGGER.info("Loan type selection");
		LoanTypes choice = null;
		LoanMaster loanMaster = null;
		while (choice != LoanTypes.GO_BACK) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (LoanTypes menu : LoanTypes.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			System.out.println("Choice");
			String customerLoginInput = read.next();
			Pattern pattern = Pattern.compile("[0-9]{1}");
			Matcher matcher = pattern.matcher(customerLoginInput);
			if (matcher.matches()) {
				int ordinal = Integer.parseInt(customerLoginInput);
				if (ordinal >= 1 && ordinal < (LoanTypes.values().length) + 1) {
					choice = LoanTypes.values()[ordinal - 1];
					switch (choice) {
					case HOME_LOAN:
						loanMaster = calculateEMI(1);
						applyLoan(customer, loanMaster);
						break;
					case EDUCATION_LOAN:
						loanMaster = calculateEMI(2);
						applyLoan(customer, loanMaster);
						break;
					case PERSONAL_LOAN:
						loanMaster = calculateEMI(3);
						applyLoan(customer, loanMaster);
						break;
					case VEHICLE_LOAN:
						loanMaster = calculateEMI(4);
						applyLoan(customer, loanMaster);
						break;
					case GO_BACK:
						System.out.println("Thank You!");
						break;
					}
				} else {
					choice = null;
					try {
						if (choice == null) {
							throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
						}
					} catch (IBSException exp) {
						System.out.println(exp.getMessage());

					}
				}

			} else {
				try {
					throw new IBSException(ExceptionMessages.MESSAGEFORINPUTMISMATCH);
				} catch (IBSException exp) {
					System.out.println(exp.getMessage());
				}
			}

		}
		return loanMaster;
	}

	public CustomerBean init(CustomerBean customer) throws IBSException {
		LOGGER.info("Logged in as an existing customer");
		CustomerOptions customerChoice = null;
		System.out.println("Welcome " + customer.getFirstName() + " " + customer.getLastName());
		while (customerChoice != CustomerOptions.LOG_OUT) {
			System.out.println("--------------------");
			System.out.println("Please select one of the following to proceed further : ");
			System.out.println("--------------------");
			for (CustomerOptions menu : CustomerOptions.values()) {
				System.out.println((menu.ordinal() + 1) + ".\t" + menu);
			}
			System.out.println("Choice");
			String customerLoginInput = read.next();
			Pattern pattern = Pattern.compile("[0-9]{1}");
			Matcher matcher = pattern.matcher(customerLoginInput);
			if (matcher.matches()) {
				int ordinal = Integer.parseInt(customerLoginInput);
				if (ordinal >= 1 && ordinal < (CustomerOptions.values().length) + 1) {
					customerChoice = CustomerOptions.values()[ordinal - 1];
					switch (customerChoice) {
					case APPLY_LOAN:
						selectLoanType(customer);
						break;
					case PAY_EMI:
						break;
					case APPLY_PRECLOSURE:
						break;
					case VIEW_HISTORY:
						break;
					case LOG_OUT:
						System.out.println("Thank You! Come Again.");
						userLogin();
					}

				} else {
					customerChoice = null;
					try {
						if (customerChoice == null)

							throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
					} catch (IBSException exp) {
						System.out.println(exp.getMessage());
					}
				}
			} else {
				try {
					throw new IBSException(ExceptionMessages.MESSAGEFORINPUTMISMATCH);
				} catch (IBSException exp) {
					System.out.println(exp.getMessage());
				}
			}
		}
		return customer;
	}

	public BankAdmins adminInit(BankAdmins bankAdmins) throws IBSException {
		AdminOptions adminChoice = null;
		while (adminChoice != AdminOptions.LOG_OUT) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (AdminOptions menu : AdminOptions.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = read.nextInt();
			if (ordinal >= 1 && ordinal < (AdminOptions.values().length) + 1) {
				adminChoice = AdminOptions.values()[ordinal - 1];
				switch (adminChoice) {
				case VERIFY_LOAN:
					verifyLoan();
					break;
				case VERIFY_PRECLOSURE:
					verifyPreClosure();
					break;
				case LOG_OUT:
					userLogin();
				}

			} else {
				adminChoice = null;
				try {
					if (adminChoice == null) {
						throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
					}
				} catch (IBSException exp) {
					System.out.println(exp.getMessage());

				}

			}
		}
		return bankAdmins;
	}

	private void verifyLoan() {
		List<LoanMaster> pendingLoans = new ArrayList<LoanMaster>();
		pendingLoans = bankService.getPendingLoans();
		if (pendingLoans.isEmpty()) {
			System.out.println("No Pending Loans!");
		} else {
			System.out.println("Following are the loans pending for verification: ");
			for (LoanMaster loanMaster : pendingLoans) {
				System.out.println(loanMaster.getApplicationNumber() + "\t"
						+ bankService.getCustomerDetailsByUci(loanMaster.getUci()).getFirstName() + "\t"
						+ bankService.getLoanTypeByTypeID(loanMaster.getTypeId()).getLoanType());
			}
			System.out.println("Enter the applicant number of the loan you want to verify: ");
			BigInteger appNumInput = read.nextBigInteger();
			LoanMaster loanMasterTemp = new LoanMaster();
			for (LoanMaster loanMaster : pendingLoans) {
				if (loanMaster.getApplicationNumber().equals(appNumInput)) {
					loanMasterTemp = loanMaster;
					break;
				}
			}
			System.out.println("Here are the details of the applied loan you chose to verify: \nApplication No.: "
					+ loanMasterTemp.getApplicationNumber() + "\nName of customer: "
					+ bankService.getCustomerDetailsByUci(loanMasterTemp.getUci()).getFirstName() + " "
					+ bankService.getCustomerDetailsByUci(loanMasterTemp.getUci()).getLastName() + "\nLoan Amount: "
					+ loanMasterTemp.getLoanAmount() + "\nLoanTenure: " + loanMasterTemp.getLoanTenure()
					+ "\nEMI Amount: INR " + loanMasterTemp.getEmiAmount());
			bankService.downloadDocument(loanMasterTemp);
			System.out.println("Document for Application Number:"+ loanMasterTemp.getApplicationNumber()+"has been Downloaded.");
			System.out.println("Do you want to approve the loan? \n1. Yes\n2. No");
			Integer loanApprovalInput = read.nextInt();
			switch (loanApprovalInput) {
			case 1:
				System.out.println("Loan with application number " + loanMasterTemp.getApplicationNumber()
						+ " has been approved.");
				LoanMaster loanMasterTempo = bankService.updateLoanApproval(loanMasterTemp);
				System.out.println("Loan number for the loan:\t" + loanMasterTempo.getLoanAccountNumber());
				break;
			case 2:
				System.out.println("Loan with application number " + loanMasterTemp.getApplicationNumber()
						+ " has been declined.");
				bankService.updateLoanDenial(loanMasterTemp);
			}
		}
	}

	private void verifyPreClosure() {

	}

	// customer Login
	private CustomerBean customerLogin() {
		LOGGER.info("Login portal");
		CustomerBean customerLoggedIn = new CustomerBean();
		boolean shallContinue = true;
		String userId = "";
		while (shallContinue) {
			System.out.println("Login with your Registered UserID");
			System.out.println("UserID: ");
			userId = read.next();
			System.out.println("Password: ");
			String password = read.next();
			shallContinue = !customerService.verifyCustomerLogin(userId, password);
			if (shallContinue) {
				System.out.println("**##Not a Registered Customer##**");
			}
		}
		if (!shallContinue) {
			customerLoggedIn = customerService.getCustomer(userId);
		}

		return customerLoggedIn;
	}

	private BankAdmins bankAdminLogin() {
		LOGGER.info("Login portal");
		BankAdmins bankAdminLoggedIn = new BankAdmins();
		boolean shallContinue = true;
		String userId = "";
		while (shallContinue) {
			System.out.println("Login with your Registered UserID");
			System.out.println("UserID: ");
			userId = read.next();
			System.out.println("Password: ");
			String password = read.next();
			shallContinue = !bankService.verifyBankLogin(userId, password);
			if (shallContinue) {
				System.out.println("**##Not a Registered Bank Admin##**");
			}
		}
		if (!shallContinue) {
			bankAdminLoggedIn = bankService.getBankAdmin(userId);
		}

		return bankAdminLoggedIn;
	}

	private void applyLoan(CustomerBean customer, LoanMaster loanMaster) {
		if (null == customer) {
			customer = callingCustomerLogin();
		}
		System.out.println("Please upload any address proof in pdf format");
		System.out.println("Enter the file path: ");
		String path = read.next();
		LOGGER.info("Your loan application has been sent for verification");
		System.out.println(customerService.applyLoan(customer, loanMaster, path).getApplicationNumber());
	}

	// customer Login for Customer
	private CustomerBean callingCustomerLogin() {
		LOGGER.info("Login portal for visitor");
		CustomerBean customer = null;
		System.out.println("Do you want to apply for this loan");
		System.out.println("1. Yes\n2. No");
		Integer input = read.nextInt();
		switch (input) {
		case 1:
			customer = customerLogin();
			break;
		case 2:
			System.out.println("Thank You for visiting");
			break;
		}
		return customer;

	}

	// EMI Calculation for Visitor/Customer
	private LoanMaster calculateEMI(Integer typeId) {
		LOGGER.info("EMI calculation");
		LoanMaster loanMaster = new LoanMaster();
		loanMaster.setTypeId(typeId);
		System.out.println("-----------------------------------------\n");
		System.out.println("Loan Type:\t" + customerService.getLoanTypeByTypeId(loanMaster.getTypeId()).getLoanType());
		System.out.println(
				"Interest Rate:\t" + customerService.getLoanTypeByTypeId(loanMaster.getTypeId()).getInterestRate());
		System.out.println("Maximum Loan Amount:\t"
				+ customerService.getLoanTypeByTypeId(loanMaster.getTypeId()).getMaximumLimit());
		System.out.println("Minimum Loan Amount:\t"
				+ customerService.getLoanTypeByTypeId(loanMaster.getTypeId()).getMinimumLimit());
		boolean shallContinue = true;
		while (shallContinue) {
			System.out.println("Enter Loan Amount: ");
			loanMaster.setLoanAmount(read.nextBigDecimal());
			shallContinue = !customerService.verifyLoanAmount(loanMaster.getLoanAmount(),
					customerService.getLoanTypeByTypeId(loanMaster.getTypeId()).getMaximumLimit(),
					customerService.getLoanTypeByTypeId(loanMaster.getTypeId()).getMinimumLimit());
			if (shallContinue) {
				System.out.println("**##Please Adhere to the Loan Limits Specified!##**");
			}
		}
		shallContinue = true;
		while (shallContinue) {
			System.out.println("Enter Loan Tenure (Months): ");
			System.out.println("\t** Tenure should be in multiples of 6 months **");
			loanMaster.setLoanTenure(read.nextInt());
			shallContinue = !customerService.verifyLoanTenure(loanMaster.getLoanTenure());
			if (shallContinue) {
				System.out.println("**##Please Adhere to the Loan Tenure limits Specified!##**");
			}
		}
		customerService.calculateEmi(loanMaster);
		System.out.println("Monthly EMI:\t" + loanMaster.getEmiAmount().toPlainString());
		return loanMaster;
	}

	public static void main(String[] args) throws IBSException {
		User user = new User();
		user.userLogin();
	}
}
